# Installation Guidelines
Using whichever package manager you prefer, install sdl version 1.2.15 and
sdl_mixer version 1.2.12.
Then run `opam install ocamlsdl`

As of now, we have the game working on linux but it is buggy on mac.